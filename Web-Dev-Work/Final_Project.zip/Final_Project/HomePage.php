	<?php 	
		//Calls Common.php
		include "Common.php";
	?>
	<!--Calls Header from Common.php-->
	<?=$head;?>

	<!--Calls Navigation Bar from Common.php-->
	<?=$NavigationBar;?>
	<br>
	<div class="body_div">
		
		
    </div>
		
    <!--Calls Footer from Common.php-->
	<?=$footer;
