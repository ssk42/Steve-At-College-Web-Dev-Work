	<?php 	
		//Calls Common.php
		include "Common.php";
	?>
	<!--Calls Header from Common.php-->
	<?=$head;?>

	<!--Calls Navigation Bar from Common.php-->
	<?=$NavigationBar;?>
	<?=$GroceryNavBar;?>

		
		<div class="right_div" id="Shopping" onload="giveMeATable();">
			
			</div>
		</div>
	</div>

    <!--Calls Footer from Common.php-->
		<?=$grocery_footer?>
  	  	<!--Calls html closer from Common.php-->
		<?=$htmlcloser?>