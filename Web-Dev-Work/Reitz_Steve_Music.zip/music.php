<!DOCTYPE html>
<html>
	<!--
	Lab: PHP, Music Page
	-->

	<head>
		<title>Music Viewer</title>
		<meta charset="utf-8" />
		<link href="viewer.css" type="text/css" rel="stylesheet" />
	</head>

	<body>
		
		<h1>My Music Page</h1>
		
		<!-- Number of Songs (Variables) -->
		<p>
			I love music.
			I have <?= $songs= count(glob("*.mp3"))?> total songs,
			which is over <?= $songs*.05 ?> hours of music!
		</p>

		<!-- Music Results Pages (Loops) -->
		<div class="section">
			<h2>Google's Music Results</h2>
		
			<ol>
				<?php
				for ($i=0; $i < 4; $i++) { 
				 	print('<li><a href="https://www.google.com/search?tbm=nws&amp;q=Music&amp;start='.$i*10." >Page ".$i.'</a></li>');
				 } ?>

				
				<li><a href="https://www.google.com/search?tbm=nws&amp;q=Music&amp;start=10">Page 2</a></li>
				<li><a href="https://www.google.com/search?tbm=nws&amp;q=Music&amp;start=20">Page 3</a></li>
				<li><a href="https://www.google.com/search?tbm=nws&amp;q=Music&amp;start=30">Page 4</a></li>
				<li><a href="https://www.google.com/search?tbm=nws&amp;q=Music&amp;start=40">Page 5</a></li>
			</ol>
		</div>

		<!-- Favorite Artists (Arrays) -->
		<!-- Favorite Artists from a File (Files) -->
		<div class="section">
			<h2>My Favorite Artists</h2>
		
			<ol>
				<?=
					$artist= file("favorite.txt");
					foreach($artist as $artists) {
						print("<li> $artists</li>");
					}

				?>
			</ol>
		</div>
		
		<!-- Music (Multiple Files) -->
		<!-- MP3 Formatting -->
		<div class="section">
			<h2>My Music and Playlists</h2>

			<ul id="musiclist">
				<!-- Exercise 8: Playlists (Files) -->
				<li class="playlistitem">154-mix.m3u:
					<ul>
						<?=
							$songs= glob("*.mp3");
							foreach ($songs as $song) {
								print("<li> <a href=$song> $song</a></li>");
							}
						?>
					</ul>
				</li>
			</ul>
		</div>
	</body>
</html>
